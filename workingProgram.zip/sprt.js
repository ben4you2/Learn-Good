function throttle(func,limit){
  
  lastFunc;
  lastRan;
  return function(...argd){
    if(!ladtRan){
      Func.apply(this.args);
      lastRan=Date.now();
    }else{
      clearTimeout(lastFunc);
      lastFunc = setTimeout((=> ){
         
         if(Date.now - lastRan >= limit ){
           
           func.apply(this, args);
           lastRan = Date.now();
         }
      }), limit - (Date.now() - lastRan});
    }
  };
}

const log = throttle( => console.log("Throttled!"),2000);
window.addEventListener('scroll',log );